function [Igeff] = Igiceff(In, rt, Xmr)
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% getting transformer ratio
alpha = Xmr(:,HKV)./Xmr(:,LKV);

%% Igic, effective
Igeff = abs((In./3).*(rt(:,1) + rt(:,2)./alpha));