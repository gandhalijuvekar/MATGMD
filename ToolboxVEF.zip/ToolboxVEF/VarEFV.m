function [Iinj, GSU_b] = VarEFV(Lines, Substn, Bus_dc, Ematrix, del, lmin, lmax)
%% define indices
[BUS_N, BUS_S, N_KV] = idx_busdc;
[F_B, T_B, LCON, CN_L] = idx_lines;
[SUB_N, N_RES, LAT, LONG] = idx_sub;

%% initialize
L_res = 1./Lines(:,LCON);
n_b = length(Bus_dc(:,BUS_N));
n_s = length(Substn(:,SUB_N));
nn = n_b + n_s;
ydist = del(1)/2;
xdist = del(2)/2;
Emag = zeros(((lmax(1) - lmin(1))/del(1)) + 1, ((lmax(2) - lmin(2))/del(2)) + 1);
Ex = zeros(((lmax(1) - lmin(1))/del(1)) + 1, ((lmax(2) - lmin(2))/del(2)) + 1);
Ey = zeros(((lmax(1) - lmin(1))/del(1)) + 1, ((lmax(2) - lmin(2))/del(2)) + 1);

%% split Ex and Ey and calculate E magnitude
for i = 1:((lmax(1) - lmin(1))/del(1)) + 1
    for j = 1:((lmax(2) - lmin(2))/del(2)) + 1
        Ex(i,j) = Ematrix(i,2*j);
        Ey(i,j) = Ematrix(i,2*j - 1);
        Emag(i,j) = sqrt((Ematrix(i,2*j - 1))^2 + (Ematrix(i,2*j))^2);
    end
end

[EUv, ~, idx]  = unique(Emag);
%zones = length(EUv);
%idxn = vec2mat(idx,4);  
%idxn = idxn';
    
x = lmin(2) : del(2) : lmax(2);
y = lmin(1) : del(1) : lmax(1);
% [X,Y] = meshgrid(x,y);
% contourf(X, Y, Emag, 1);    
%% border points
ybor = lmin(1) - del(1)/2: del(1): lmax(1) + del(1)/2;
xbor = lmin(2) - del(2)/2: del(2): lmax(2) + del(2)/2;  

%% Bus Latitudes and Longitudes
for i = 1:length(Bus_dc(:,1))
    BusLL(i,:) = Substn(Bus_dc(i,BUS_S), LAT:LONG);
end

%% Lines zones and intersection points;
for i = 1:length(Lines(:,1))
    LineZ(i,1:2) = BusLL(Lines(i,F_B),:);
    LineZ(i,3:4) = BusLL(Lines(i,T_B),:);
end
    
int_py = zeros(length(Lines(:,1)), length(xbor) - 2);
int_px = zeros(length(Lines(:,1)), length(ybor) - 2);
for i = 1:length(Lines(:,1))
    prody = (LineZ(i,1) - ybor).*(LineZ(i,3) - ybor);
    prodx = (LineZ(i,2) - xbor).*(LineZ(i,4) - xbor);
    zonechy = find(prody < 0);
    zonechx = find(prodx < 0);
    zonechn(i,:) = [length(zonechy), length(zonechx)];
    slope(i) = (LineZ(i,3) - LineZ(i,1))/(LineZ(i,4) - LineZ(i,2));
    c(i) = LineZ(i,3) - slope(i)*(LineZ(i,4));
    for j = 1:zonechn(i,1)
        int_px(i,zonechy(j) - 1) = (ybor(zonechy(j)) - c(i))/slope(i);
    end
    for k = 1:zonechn(i,2)
        int_py(i,zonechx(k) - 1) = slope(i)*xbor(zonechx(k)) + c(i);
    end
end

% if length(xbor) > length(ybor)
%     int_px(:,length(ybor) + 1:length(xbor) - 2) = zeros(length(Lines(:,1)),length(xbor) - length(ybor) - 2);
% end
% if length(xbor) < length(ybor)
%     int_py(:,length(xbor) + 1:length(ybor) - 2) = zeros(length(Lines(:,1)),length(ybor) - length(xbor) - 2);
% end

 %% order
for i = 1:length(Lines(:,1))
    coor(1,1,i) = LineZ(i,1);
    coor(1,2,i) = LineZ(i,2);
    k = 2;
    for j = 1:length(ybor) - 2
        if int_px(i,j) ~= 0
            coor(k,1,i) = ybor(j + 1);
            coor(k,2,i) = int_px(i,j);
            k = k + 1;
        end
    end
    for j = 1:length(xbor) - 2
        if int_py(i,j) ~= 0
            coor(k,1,i) = int_py(i,j);
            coor(k,2,i) = xbor(j + 1);
            k = k + 1;    
        end
    end
    coor(k,1,i) = LineZ(i,3);
    coor(k,2,i) = LineZ(i,4);    
    if LineZ(i,2) < LineZ(i,4)
        [~, I] = sort(coor(:,2,i));
        coor(:,:,i) = coor(I,:,i);
    else
        [~, I] = sort(coor(:,2,i),'descend');
        coor(:,:,i) = coor(I,:,i);        
    end
end
    
%% Lengths
Ln = zeros(length(Lines(:,1)), length(coor(:,1,1)) - 1);                 
Le = Ln;

for i = 1:length(Lines(:,1))
    for j = 1:(length(coor(:,1,1)) - 1)
        if coor(j,1,i) ~= 0 && coor(j+1,1,i) ~= 0
            Ln(i,j) = (111.113 - 0.56.*cosd(coor(j,1,i) + coor(j+1,1,i))).* (coor(j,1,i) - coor(j+1,1,i));
            Le(i,j) = (111.5065 - 0.1872.*cosd(coor(j,1,i) + coor(j+1,1,i))) .* (coor(j,2,i) - coor(j+1,2,i)) .* sind(90 - (coor(j,1,i) + coor(j+1,1,i))/2);
        end
    end
end

%% Zone for each length
m = zeros(length(Lines(:,1)), length(coor(:,1,1)) - 1);                 
n = m;
for i = 1:length(Lines(:,1))
    for j = 1:(length(coor(:,1,1)) - 1)
        if coor(j,1,i) ~= 0 && coor(j+1,1,i) ~= 0
            mid_lat(i,j) = (coor(j,1,i) + coor(j+1,1,i))/2;
            mid_long(i,j) = (coor(j,2,i) + coor(j+1,2,i))/2;
            diffy = abs(mid_lat(i,j) - y');
            diffx = abs(mid_long(i,j) - x');
            m(i,j) = abs(find(diffy < ydist) - length(y) - 1);
            n(i,j) = find(diffx < xdist);
        end
    end
end
    
%% Vdc for the TLs:
Vdc = zeros(length(Lines(:,1)),1);
ILines = zeros(length(Lines(:,1)),1);
for i = 1:length(Lines(:,1))
    for j = 1:(length(coor(:,1,1)) - 1)
        if m(i,j) ~= 0 && n(i,j) ~= 0
            Vdc(i) = Vdc(i) + Ln(i,j)*Ey(m(i,j),n(i,j)) + Le(i,j)*Ex(m(i,j),n(i,j));
        end
    end
    ILines(i) = Vdc(i)./L_res(i);
end
%% Injection currents
Iinj = zeros(nn, 1);
for i = n_s+1:nn
        j = Lines(:,F_B) == i - n_s;
        k = Lines(:,T_B) == i - n_s;
        IL1(i) = sum(ILines(j));
        IL2(i) = sum(ILines(k));
        Iinj(i) = 3*(IL1(i) - IL2(i));
end
        
%% remove zero rows and columns
i = 1;
k = 1;
Iinj(:,2) = Iinj;
Iinj(:,1) = 1:nn;
while i <= length(Iinj(:,2))
    if i > n_s
    if Iinj(i,2) == 0
        Iinj(i,:) = [];
        GSU_b(k,1) = Iinj(i,1) - n_s - 1; %#ok<AGROW>
        i = i - 1;
        k = k + 1;
    end
    end
    i = i + 1;
end         
    
   