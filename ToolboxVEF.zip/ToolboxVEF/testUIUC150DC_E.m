function testUIUC150DC_E
%% define named indices into data matrices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% input file
caseGMD = 'UIUC150_DC2.m';
caseEfield = 'UIUC150Eip_2';
isuniform = 0;
baseMVA = 100;

%% Run GMD
[et, In, rt, Igeff] = runGMD(caseGMD, caseEfield, isuniform);

%% output
[Xmr, Bus_dc, Substn, Lines] = loadGMD(caseGMD);

%% actual vs calculated plot
% figure
% plot(1:15,In, 'r', 1:15, Xmr(:,INEU), 'b') 
Ibpeak = (baseMVA./Xmr(:,HKV)).*(sqrt(2/3)).*1000;

[Ineut] = Ineu2;
%% error profile
figure
plot(log10(abs(In - Ineut)./Ibpeak))
xlabel('Transformer number')
ylabel('log absolute error')
title('log absolute error in pu Neutral Currents for all the Transformers')

figure 
plot(((In - Ineut)./Ineut)*100)
xlabel('Transformer number')
ylabel('Percent error')
title('Percent Error in Neutral Currents for all the Transformers')