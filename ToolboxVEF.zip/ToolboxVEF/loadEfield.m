function [Ematrix, del, lmin, lmax, info] = loadEfield(casefile)
info = 0;
%% Read file
if ischar(casefile)
    [pathstr, fname, ext] = fileparts(casefile);
    if isempty(ext)
        if exist(fullfile(pathstr, [fname '.mat']), 'file') == 2
            ext = '.mat';
        elseif exist(fullfile(pathstr, [fname '.m']), 'file') == 2
            ext = '.m';
        else
            info = 2;
        end
    end
    %% attempt to read file
    if info == 0
        if strcmp(ext,'.mat')       %% from MAT file
            try
                s = load(fullfile(pathstr, fname));
            catch
                info = 3;
            end
        elseif strcmp(ext,'.m')     %% from M file
            if ~isempty(pathstr)
                cwd = pwd;          %% save working directory to string
                cd(pathstr);        %% cd to specified directory
            end
            try                             %% assume it returns a struct
                s = feval(fname);
            catch
                info = 4;
            end
            if info == 0 && ~isstruct(s)    %% if not try individual data matrices
                clear s;
                try
                    [s.Ematrix, s.del, s.lmin, s.lmax] = feval(fname);
                catch
                    info = 4;
                end
             end
            if info == 4 && exist(fullfile(pathstr, [fname '.m']), 'file') == 2
                info = 5;
                err5 = lasterr;
            end
            if ~isempty(pathstr)    %% change working directory back to original
                cd(cwd);
            end
        end
    end
elseif isstruct(casefile)
    s = casefile;
else
    info = 1;
end

%% -----  define output variables  -----
if info == 0    %% no errors
    Ematrix = s.Ematrix;
    del  = s.del;
    lmin  = s.lmin;
    lmax   = s.lmax;
else            %% we have a problem captain
    if nargout == 2 || nargout == 6   %% return error code
        Ematrix = []; del = []; lmin = []; lmax = [];
    else                                            %% die on error
        switch info
            case 1
                error('loadcase: input arg should be a struct or a string containing a filename');
            case 2
                error('loadcase: specified case not in MATLAB''s search path');
            case 3
                error('loadcase: specified MAT file does not exist');
            case 4
                error('loadcase: specified M file does not exist');
            case 5
                error('loadcase: syntax error or undefined data matrix(ices) in the file\n%s', err5);
            otherwise
                error('loadcase: unknown error');
        end
    end
end