function [Anew, L, U, y, x] = LUfact(A, b)
n = length(A(:,1));
Anew = A;

for i = 2:n
    for j = 1:i-1
        Anew(i,j) = Anew(i,j)/Anew(j,j);
        for k = j+1:n
            Anew(i,k) = Anew(i,k) - Anew(i,j)*Anew(j,k);
        end
    end
end

L = zeros(n,n);
for i = 1:n
    for j = 1:i-1
        L(i,j) = Anew(i,j);
    end
    L(i,i) = 1;
end

U = zeros(n,n);
for i = 1:n
    for j = i:n
        U(i,j) = Anew(i,j);
    end
end

y = b;
for i = 2:n
    for j = 1:i-1
        y(i) = y(i) - Anew(i,j)*y(j);
    end
end

x = y;
for i = n:-1:1
    for j = i+1:n
        x(i) = x(i) - Anew(i,j)*x(j);
    end
    x(i) = x(i)/Anew(i,i);
end

        