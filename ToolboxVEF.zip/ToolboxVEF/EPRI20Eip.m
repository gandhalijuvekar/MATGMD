function [Ematrix, del, lmin, lmax] = EPRI20Eip
%% input
%GIC3DMatrixRow
%Lon:  -88.000	Lon:  -86.000	Lon:  -84.000	Lon:  -82.000
Ematrix = [
    0.500, 1.000	0.500, 1.000	1.000, 1.000	1.000, 1.000
    0.500, 1.000	0.500, 1.000	1.000, 1.000	1.000, 1.000
    0.500, 1.000	0.500, 1.000	1.000, 1.000	1.000, 1.000
    0.500, 1.000	0.500, 1.000	1.000, 1.000	1.000, 1.000
    ];

%% step size
%    ydel xdel
del = [1; 2];

%% min values
%    ymin  xmin
lmin = [32; -88];

%% max values
%    ymax  xmax
lmax = [35; -82];