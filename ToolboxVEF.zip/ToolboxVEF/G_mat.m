function [g] = G_mat(Xmr, Bus_dc, Substn, Lines)
format long
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;
[BUS_N, BUS_S, N_KV] = idx_busdc;
[SUB_N, N_RES, LAT, LONG] = idx_sub;
[F_B, T_B, LCON, CN_L] = idx_lines;

%% getting length of each  component
n_x = length(Xmr(:,HKV));
n_b = length(Bus_dc(:,BUS_N));
n_s = length(Substn(:,SUB_N));
n_l = length(Lines(:,F_B));
nn = n_b + n_s;

%% Conductances
Hcond = 1./Xmr(:,H_RES);
Mcond = 1./Xmr(:,L_RES);
Scond = 1./Substn(:,N_RES);
Licond = Lines(:,LCON);

%% Label matrix
pol_mat = zeros(nn,nn);

for i = 1:n_x %transformer branches
    if Xmr(i,AUT)
        pol_mat(Xmr(i,HSB) + n_s,Xmr(i,LSB) + n_s) = 1;
    end
end
for i = 1:n_l % Lines
    pol_mat(Lines(i,F_B) + n_s,Lines(i,T_B) + n_s) = -1;
end
for i = 1:n_x % Substation to bus
    if Xmr(i,YY) && ~Xmr(i,AUT)    
        pol_mat(Xmr(i,TR_S),Xmr(i,HSB) + n_s) = 1;    
        pol_mat(Xmr(i,TR_S),Xmr(i,LSB) + n_s) = 1;            
    end
    if ~Xmr(i,YY)
        pol_mat(Xmr(i,TR_S),Xmr(i,HSB) + n_s) = 1;
    end
    if Xmr(i,AUT)
        pol_mat(Xmr(i,TR_S),Xmr(i,LSB) + n_s) = 1;
    end
end

%% Calculations
g = zeros(nn,nn);
% non-diagonal elements
for i = 1:nn
    for j = 1:nn
        if i <= n_s && pol_mat(i,j) 
            bus_no = j - n_s;
            if ~isempty(find(Xmr(:,HSB) == bus_no,1))
                x_mat = (find(Xmr(:,HSB) == bus_no));
                for k = 1:length(x_mat)
                    if ~Xmr(x_mat(k),AUT)
                        g(i,j) = g(i,j) - Hcond(x_mat(k));
                    end
                end
                g(i,j) = g(i,j)*3;
                g(j,i) = g(i,j);
            end
            if ~isempty(find(Xmr(:,LSB) == bus_no,1))
                x_mat = (find(Xmr(:,LSB) == bus_no));
                for k = 1:length(x_mat)
                    g(i,j) = g(i,j) - Mcond(x_mat(k));
                end
                g(i,j) = g(i,j)*3;
                g(j,i) = g(i,j);
            end
        end
        if i > n_s && j > n_s
            if pol_mat(i,j) == -1
                x_mat = find(Lines(:,F_B) == i - n_s);
                y_mat = find(Lines(x_mat,T_B) == j - n_s);
                for k = 1:length(y_mat)
                    g(i,j) = g(i,j) - Licond(x_mat(y_mat(k)));
                end
                g(i,j) = g(i,j)*3;
                g(j,i) = g(i,j);
            elseif pol_mat(i,j)
                x_mat = find(Xmr(:,HSB) == i - n_s);
                y_mat = find(Xmr(x_mat,AUT) == 1);
                for k = 1:length(y_mat)           
                    g(i,j) = g(i,j) - Hcond(x_mat(y_mat(k)));
                end
                g(i,j) = g(i,j)*3;
                g(j,i) = g(i,j);
            end
        end
    end
end
%diagonal elements
for i = 1:nn
    if i <= n_s       
        g(i,i) = sum(g(i,:)) * (-1) + Scond(i);
    else
        g(i,i) = sum(g(i,:)) * (-1);
    end
end

i = 1;
while i <= length(g(:,1))
     if ~g(i,:)
         g(i,:) = [];
         i = i - 1;
     end
     i = i + 1;
end
i = 1;
while i <= length(g(1,:))
     if ~g(:,i)
         g(:,i) = [];
         i = i - 1;
     end
     i = i + 1;
end
        