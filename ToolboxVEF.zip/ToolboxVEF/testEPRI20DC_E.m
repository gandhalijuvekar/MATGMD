function testEPRI20DC_E
%% define named indices into data matrices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% input file
caseGMD = 'EPRI20_DC4.m';
caseEfield = 'EPRI20Eip_2';
isuniform = 0;
baseMVA = 100;

%% Run GMD
[et, In, rt, Igeff] = runGMD(caseGMD, caseEfield, isuniform);

%% output
[Xmr, Bus_dc, Substn, Lines] = loadGMD(caseGMD);

Ineut = Ineu20_1;
%% actual vs calculated plot
% figure
% plot(1:15,In, 'r', 1:15, Xmr(:,INEU), 'b') 

%% error profile
Ibpeak = (baseMVA./Xmr(:,HKV)).*(sqrt(2/3)).*1000;

figure
plot(log10(abs(In - Ineut)./Ibpeak))
xlabel('Transformer number')
ylabel('log absolute error')
title('log absolute Error in pu Neutral Currents for all the Transformers')

figure 
plot(((In - Ineut)./Ineut)*100)
xlabel('Transformer number')
ylabel('Percent error')
title('Percent Error in Neutral Currents for all the Transformers')