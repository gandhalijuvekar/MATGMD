function [HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr
%% define the indices
HKV       = 1;    %% sub#, substation number
LKV       = 2;    %% Neu_Res, neutral resistance
HSB       = 3;    %% lat, latitude 
LSB       = 4;    %% long, longitude 
H_RES     = 5;    %% sub#, substation number
L_RES     = 6;    %% Neu_Res, neutral resistance
AUT       = 7;    %% lat, latitude 
YY        = 8;    %% long, longitude 
TR_S      = 9;    %% sub#, substation number
CN_TR     = 10;    %% Neu_Res, neutral resistance
KVAL      = 11;    %% lat, latitude 
INEU      = 12;    %% long, longitude 