function [Vnodes] = Vdcnodes(g, Iinj, GSU_b, Bus_dc, Substn)
%% define named indices
[BUS_N, BUS_S, N_KV] = idx_busdc;
[SUB_N, N_RES, LAT, LONG] = idx_sub;

%% initialization
n_s = length(Substn(:,SUB_N));

%% calculations
V(:,1) = Iinj(:,1);
V(:,2) = inv(g)*Iinj(:,2); %#ok<MINV>

sub = zeros(length(GSU_b),1);
for i =  1:length(GSU_b)
    sub(i,1) = Bus_dc(GSU_b(i),BUS_S); 
end

GSU_bs = [GSU_b, sub];

V_gsu(:,1) = GSU_b + n_s;
for i = 1:length(GSU_b)
    V_gsu(i,2) = V(GSU_bs(i,2),2);
end

V = [V; V_gsu];

[~, idx] = sort(V(:,1));
Vnodes = V(idx,:);
