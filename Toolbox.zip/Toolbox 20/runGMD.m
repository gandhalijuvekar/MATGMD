function [et, In, rt, Igeff] = runGMD(caseGMD, caseEfield, isuniform)
%% define named indices into data matrices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% GMD and E field input %% GMD and E field input 
if ~isuniform
    [Xmr, Bus_dc, Substn, Lines] = loadGMD(caseGMD);
    [Ematrix, del, lmin, lmax] = loadEfield(caseEfield);
else
    [Xmr, Bus_dc, Substn, Lines, ~, E] = loadGMD(caseGMD);
end

[i2e, Bus_dc, Xmr, Lines] = ext2int_dc(Bus_dc, Xmr, Lines);

t0 = clock;
%% G matrix
[g] = G_mat(Xmr, Bus_dc, Substn, Lines);

%% Injection currents
if ~isuniform
    [Iinj, GSU_b] = VarEFV(Lines, Substn, Bus_dc, Ematrix, del, lmin, lmax);
else 
    [Iinj, GSU_b] = InjC(E, Bus_dc, Substn, Lines);
end

%% Vdc at each bus and substation
[Vnodes] = Vdcnodes(g, Iinj, GSU_b, Bus_dc, Substn);

%% transformer high side, low side, neutral currents
[Is, Itr, In, rt] = XmrI(Xmr, Substn, Vnodes);

%% Igic effective calculation
[Igeff] = Igiceff(In, rt, Xmr);

et = etime(clock, t0);