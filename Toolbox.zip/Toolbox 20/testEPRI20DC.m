function [In, rt, Igeff] = testEPRI20DC
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% input file
caseGMD = 'EPRI20_DC2.m';
caseEfield = 'nil';
isuniform = 1;

%% Run GMD
[et, In, rt, Igeff] = runGMD(caseGMD, caseEfield, isuniform);

%% output
[Xmr, Bus_dc, Substn, Lines] = loadGMD(caseGMD);

%% actual vs calculated plot
% figure
% plot(1:15,In, 'r', 1:15, Xmr(:,INEU), 'b') 

%% error profile
figure
plot(abs(In - Xmr(:,INEU)))
xlabel('Transformer number')
ylabel('Absolute error')
title('Absolute Error in Neutral Currents for all the Transformers')

figure 
plot(((In - Xmr(:,INEU))./Xmr(:,INEU))*100)
xlabel('Transformer number')
ylabel('Percent error')
title('Percent Error in Neutral Currents for all the Transformers')