function testTVA150DC1
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% input file
caseGMD = 'TVA150_DC1.m';
caseEfield = 'nil';
isuniform = 1;

%% Run GMD
[et, In, rt, Igeff] = runGMD(caseGMD, caseEfield, isuniform);

%% output
[Xmr, Bus_dc, Substn, Lines] = loadGMD(caseGMD);
In_P = Xmr(:,INEU);

%% actual vs calculated plot
% figure
% plot(1:15,In, 'r', 1:15, Xmr(:,INEU), 'b') 

%% error profile
figure
plot(abs(In - In_P))
xlabel('Transformer number')
ylabel('Absolute error')
title('Absolute Error in Neutral Currents for all the Transformers')

figure 
plot(((In - In_P)./In_P)*100)
xlabel('Transformer number')
ylabel('Percent error')
title('Percent Error in Neutral Currents for all the Transformers')