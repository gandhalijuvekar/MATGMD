function [Is, Itr, In, rt] = XmrI(Xmr, Substn, Vnodes)
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;
[SUB_N, N_RES, LAT, LONG] = idx_sub;

%% getting length of each  component
n_x = length(Xmr(:,HKV));
n_s = length(Substn(:,SUB_N));
Hcond = 1./Xmr(:,H_RES);
Mcond = 1./Xmr(:,L_RES);

%% Substation currents
Is = zeros(n_s,2);
Is(:,1) = 1: n_s;

for i = 1:n_s
    Is(i,2) = (1/Substn(i,N_RES)) * Vnodes(i,2);
end

%% Transformer currents
Itr = zeros(n_x,3);
Itr(:,1) = 1: n_x;

for i = 1:n_x
    if ~Xmr(i,YY)
        Itr(i,2) = Hcond(i)*(Vnodes(n_s + Xmr(i,HSB),2) - Vnodes(Xmr(i,TR_S),2));
    elseif Xmr(i,AUT) && Xmr(i,YY)
        Itr(i,2) = Hcond(i)*(Vnodes(n_s + Xmr(i,HSB),2) - Vnodes(Xmr(i,LSB) + n_s,2));
        Itr(i,3) = Mcond(i)*(Vnodes(n_s + Xmr(i,LSB),2) - Vnodes(Xmr(i,TR_S),2)) - Itr(i,2);
    else 
        Itr(i,2) = Hcond(i)*(Vnodes(n_s + Xmr(i,HSB),2) - Vnodes(Xmr(i,TR_S),2));
        Itr(i,3) = Mcond(i)*(Vnodes(n_s + Xmr(i,LSB),2) - Vnodes(Xmr(i,TR_S),2));
    end
end

%% ratios
In = (Itr(:,2) + Itr(:,3))*3;
rt(:,1) = 3.*(Itr(:,2)./(In));
rt(:,2) = 3.*(Itr(:,3)./(In));
