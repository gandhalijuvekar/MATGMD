function [i2e, Bus_dc, Xmr, Lines] = ext2int_dc(Bus_dc, Xmr, Lines)
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;
[BUS_N, BUS_S, N_KV] = idx_busdc;
[F_B, T_B, LCON, CN_L] = idx_lines;

%% create map of external bus numbers to bus indices
i2e = Bus_dc(:, BUS_N);
e2i = sparse(max(i2e), 1);
e2i(i2e) = (1:size(Bus_dc, 1))';

%% renumber buses consecutively
Bus_dc(:, BUS_N) = e2i( Bus_dc(:, BUS_N));
Xmr(:, HSB) = e2i( Xmr(:, HSB));
Xmr(:, LSB) = e2i( Xmr(:, LSB));
Lines(:, F_B) = e2i(Lines(:, F_B));
Lines(:, T_B) = e2i(Lines(:, T_B));