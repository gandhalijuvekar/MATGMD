function [In, rt, Igeff] = testTVA150DC
%% define named indices
[HKV, LKV, HSB, LSB, H_RES, L_RES, AUT, YY, TR_S, CN_TR, KVAL, INEU] = idx_xmr;

%% input file
[Xmr, Bus_dc, Substn, Lines, E, ~] = TVA150_DC;
[i2e, Bus_dc, Xmr, Lines] = ext2int_dc(Bus_dc, Xmr, Lines);

%% G matrix
g = vpa(G_mat(Xmr, Bus_dc, Substn, Lines));

%% Injection currents
[Iinj, GSU_b] = InjC(E, Bus_dc, Substn, Lines);

%% Vdc at each bus and substation
[Vnodes] = Vdcnodes(g, Iinj, GSU_b, Bus_dc, Substn);

%% transformer high side, low side, neutral currents
[Is, Itr, In, rt] = XmrI(Xmr, Substn, Vnodes);

%% Igic effective calculation
[Igeff] = Igiceff(In, rt, Xmr);

[In_P] = get_In;

%% error profile
figure
plot(abs(In - In_P))
xlabel('Transformer number')
ylabel('Absolute error')
title('Absolute Error in Neutral Currents for all the Transformers')

figure 
plot(((In - In_P)./In_P)*100)
xlabel('Transformer number')
ylabel('Percent error')
title('Percent Error in Neutral Currents for all the Transformers')