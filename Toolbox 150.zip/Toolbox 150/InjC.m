function [Iinj, GSU_b] = InjC(E, Bus_dc, Substn, Lines)
%% define named indices
[BUS_N, BUS_S, N_KV] = idx_busdc;
[SUB_N, N_RES, LAT, LONG] = idx_sub;
[F_B, T_B, LCON, CN_L] = idx_lines;

%% initialization
n_b = length(Bus_dc(:,BUS_N));
n_s = length(Substn(:,SUB_N));
nn = n_b + n_s;
Iinj = zeros(nn, 1);
L_res = 1./Lines(:,LCON);

%% calculations
for i = n_s+1:nn
    j = find(Lines(:,F_B) == i - n_s);
    k = find(Lines(:,T_B) == i - n_s);
    indx = [j; k];
    m = length(j);
    o = length(k);
    l = [Lines(j,F_B) Lines(j,T_B); Lines(k,F_B) Lines(k,T_B)];
    subs1 = [Bus_dc(l(:,1),BUS_S) Bus_dc(l(:,2),BUS_S)];
    coord = [Substn(subs1(:,1),LAT) Substn(subs1(:,1),LONG) Substn(subs1(:,2),LAT) Substn(subs1(:,2),LONG)];
    Dist = [(111.113 - 0.56.*cosd(coord(1:m,1) + coord(1:m,3))).* (coord(1:m,1) - coord(1:m,3)),... 
        (111.5065 - 0.1872.*cosd(coord(1:m,1) + coord(1:m,3))) .* (coord(1:m,2) - coord(1:m,4)) .* sind(90 - (coord(1:m,1) + coord(1:m,3))/2); 
        (111.113 - 0.56.*cosd(coord(1 + m:m + o,1) + coord(1 + m:m + o,3))) .* (coord(m + 1:m + o,3) - coord(m + 1:m + o,1)), ...
        (111.5065 - 0.1872.*cosd(coord(1 + m:m + o,1) + coord(1 + m:m + o,3))) .* (coord(m + 1:m + o,4) - coord(m + 1:m + o,2)) .* sind(90 - (coord(m + 1:m + o,1) + coord(m + 1:m + o,3))/2)];
    H_ini = 3.*[Dist(:,1)./L_res([j;k]), Dist(:,2)./L_res([j;k])];
    if length(E(1,:)) > 1
        H_int = H_ini * E(:,indx);
    else
        H_int = H_ini * E;
    end
    %H_V = [Dist(:,1), Dist(:,2)]*E; %#ok<NASGU> %dc input voltages check
    Iinj(i) = sum(H_int);
end

Iinj(:,2) = Iinj;
Iinj(:,1) = 1:nn;

%% remove zero rows and columns
i = 1;
k = 1;
while i <= length(Iinj(:,2))
    if i > n_s
    if Iinj(i,2) == 0
        Iinj(i,:) = [];
        GSU_b(k,1) = Iinj(i,1) - n_s - 1; %#ok<AGROW>
        i = i - 1;
        k = k + 1;
    end
    end
    i = i + 1;
end       
