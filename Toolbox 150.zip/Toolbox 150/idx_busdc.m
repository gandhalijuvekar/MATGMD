function [BUS_N, BUS_S, N_KV] = idx_busdc
%% define the indices
BUS_N     = 1;    %% bus#, bus number
BUS_S     = 2;    %% sub#, bus substation
N_KV      = 3;    %% NomkV, Nominal kV