function [F_B, T_B, LCON, CN_L] = idx_lines
%% define the indices
F_B       = 1;    %% f, from bus number
T_B       = 2;    %% t, to bus number
LCON      = 3;    %% g, conductance (p.u.)
CN_L      = 4;    %% x, circuit number 