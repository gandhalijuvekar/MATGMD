function [SUB_N, N_RES, LAT, LONG] = idx_sub
%% define the indices
SUB_N     = 1;    %% sub#, substation number
N_RES     = 2;    %% Neu_Res, neutral resistance
LAT       = 3;    %% lat, latitude 
LONG      = 4;    %% long, longitude 